import cv2
import numpy as np
from itertools import permutations, combinations, product

def lerp(v0, v1, i):
    """
    Performs linear interpolation between two values.

    :param v0: The start value.
    :param v1: The end value.
    :param i: The interpolation factor, where 0 <= i <= 1.
    :return: The interpolated value.
    """
    return v0 + i * (v1 - v0)

def getEquidistantPoints(p1, p2, n):
    """
    Calculates n equidistant points between two points.

    :param p1: The starting point (x, y).
    :param p2: The ending point (x, y).
    :param n: The number of segments to divide the line into.
    :return: A list of equidistant points along the line from p1 to p2.
    """
    return [(lerp(p1[0], p2[0], 1./n * i), lerp(p1[1], p2[1], 1./n * i)) for i in range(n+1)]

def interpolate(image, corners, chessboard_size):
    """
    Interpolates and draws a chessboard grid on an image based on provided corner points.

    :param image: The image on which to draw the chessboard.
    :param corners: A list of four corner points [(x1, y1), (x2, y2), (x3, y3), (x4, y4)].
    :param chessboard_size: A tuple indicating the number of internal corners in the chessboard (rows, cols).
    :return: A tuple containing the modified corner points as a NumPy array and the annotated image.
    """
    rows, cols = chessboard_size

    eqpoints_x_above = getEquidistantPoints(corners[0], corners[1], rows+1)
    eqpoints_x_bellow = getEquidistantPoints(corners[3], corners[2], rows+1)
    eqpoints_y_left = getEquidistantPoints(corners[0], corners[3], cols+1)
    eqpoints_y_right = getEquidistantPoints(corners[1], corners[2], cols+1)

    auxiliar_line_vertical = []  

    for i in range(len(eqpoints_x_above)):
        start_point = (int(eqpoints_x_above[i][0]), int(eqpoints_x_above[i][1]))
        end_point = (int(eqpoints_x_bellow[i][0]), int(eqpoints_x_bellow[i][1]))
        auxiliar_line = getEquidistantPoints(start_point, end_point, cols+1)
        auxiliar_line = auxiliar_line[1:-1]  

        auxiliar_line_vertical.append(auxiliar_line)

    auxiliar_line_vertical = auxiliar_line_vertical[1:-1]

    for i in range(len(auxiliar_line_vertical)):
        line = auxiliar_line_vertical[i]
        cv2.line(image, (int(line[0][0]), int(line[0][1])), (int(line[-1][0]), int(line[-1][1])), (255,0,0), 1)
        if i < len(auxiliar_line_vertical)-1:
            next_line = auxiliar_line_vertical[i+1]
            cv2.line(image, (int(line[0][0]), int(line[0][1])), (int(next_line[-1][0]), int(next_line[-1][1])), (255,0,0), 1)

        for point in line:
            cv2.circle(image, (int(point[0]), int(point[1])), 6, (255, 0, 0))

    corners_np = np.array(auxiliar_line_vertical, dtype=np.float32).reshape(-1, 1, 2)
    sorted_indices = np.argsort(corners_np[:, :, 1].flatten())  

    corners_modified = corners_np[sorted_indices]  
    #print("Corners2",corners_modified)  

    return corners_modified, image